import MOD
import argparse
import read

parser = argparse.ArgumentParser()
parser.add_argument('host')
parser.add_argument('host_final')
parser.add_argument('-e', '--escaner', help='ESCANEAR IP + PUERTO',
                    action='store_true')

parser.add_argument('port', type=int)
parser.add_argument('port_final', type=int )
parser.add_argument('-t', '--tiempo', help='Muestra por segundos cuanta tarda en escanear',
                    action='store_true')

parser.add_argument('-E', '--encriptar', help='Creara un archivo TXT con el resultado!',
                                              action='store_true')

args = parser.parse_args()

if args.escaner and not args.tiempo and not args.encriptar:
    print('Escaneando', args.host)
    print('MODO ENCRIPTAR: ',args.encriptar)

    MOD.mode_normal(args.host, args.host_final, args.port, args.port_final)

elif args.tiempo and args.escaner and not args.encriptar:

    print('Escaneando', args.host)
    print('MODO MEDIDA DE TIEMPO')
    print('MODO ENCRIPTAR: ',args.encriptar)

    MOD.mode_time(args.host, args.host_final, args.port, args.port_final)


elif args.escaner and args.encriptar and not args.tiempo:

    print('Escaneando', args.host)
    print('MODO ENCRIPTAR: ', args.encriptar)

    read.write_files(f'Escaneando: {args.host}', 'arxiu.txt')
    read.write_files(f'MODO MEDIDA DE TIEMPO', 'arxiu.txt')

    MOD.mode_normal_ENCRIPTAR(args.host, args.host_final, args.port, args.port_final)

elif args.escaner and args.tiempo and args.encriptar:

    print('Escaneando', args.host)
    print('MODO ENCRIPTAR: ',args.encriptar)
    print('MODO MEDIDA DE TIEMPO')

    read.write_files(f'Escaneando: {args.host}', 'arxiu.txt')
    read.write_files(f'MODO MEDIDA DE TIEMPO', 'arxiu.txt')
    read.write_files(f'MODO ENCRIPTAR: {args.encriptar}', 'arxiu.txt')
    MOD.mode_time_ENCRIPTAR(args.host, args.host_final, args.port, args.port_final)

else:
    print('Incompleto utiliza -h --help para buscar parametros')





