
def read_text(file):
    with open(file) as f:
        lines = f.readlines()
    return lines


text_ = []
def write_files(text, file):
    with open(file, 'w') as f:
        text_.append(text)
        for line in text_:
            f.write(line)
            f.write('\n')
