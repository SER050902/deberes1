import read
import scaner
from datetime import  datetime, timedelta


time_ = datetime.now()
time_fin = time_.strftime("%d/%m/%y  %H:%M:%S")


puerto_disponibles = {
    "DISPONIBLES": [],
    "NO DISPONIBLES": []
}



def mode_normal_ENCRIPTAR(ip, ip_final, puerto,puerto_final ):

    print('Rango: ', ip_final )
    print('Puerto: ', puerto)
    print('Puerto Final: ', puerto_final)

    
    read.write_files(f'Rango: {ip_final}', 'arxiu.txt')
    read.write_files(f'Puerto: {puerto}', 'arxiu.txt')
    read.write_files(f'Puerto final: {puerto_final}', 'arxiu.txt')
    read.write_files('------------------------------------------', 'arxiu.txt')

    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])
    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            break

        IP = ip
        scaner.scan_ENCRIPT(ip, puerto, 2)
        puerto = puerto + 1

        if puerto == puerto_final + 1:

            print('------------------------------------------')
            
            read.write_files('------------------------------------------', 'arxiu.txt')

            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')
                
                read.write_files(f'{IP} TODOS DISPONIBLES!', 'arxiu.txt')


            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}: NO DISPONIBLE!')
                
                read.write_files(f'{IP} NO DISPONIBLES!', 'arxiu.txt')


            else:
                print(f'{IP}: DISPONIBLE')
                
                read.write_files(f'{IP} DISPONIBLES', 'arxiu.txt')

            print('------------------------------------------')
            
            read.write_files('------------------------------------------', 'arxiu.txt')


            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()
def mode_time_ENCRIPTAR(ip, ip_final, puerto,puerto_final ):
    ini = datetime.now()
    read.write_files(f'Fecha actual:  {time_fin}', 'arxiu.txt')
    read.write_files(f'Rango: {ip_final}', 'arxiu.txt')
    read.write_files(f'Puerto: {puerto}', 'arxiu.txt')
    read.write_files(f'Puerto final: {puerto_final}', 'arxiu.txt')

    print('Fecha actual: ', time_fin)
    print('Ip: ',ip)
    print('Rango: ', ip_final)
    print('Puerto: ', puerto)
    print('Puerto_final: ', puerto_final)

    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])

    
    read.write_files('------------------------------------------', 'arxiu.txt')
    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            read.write_files(time_fin, 'arxiu.txt')
            print(time_fin)
            break

        IP = ip
        scaner.scan_time_ENCRIPT(ip, puerto, 5)
        puerto = puerto + 1


        if puerto == puerto_final + 1:

            duracion_ip_ENCRIPT(ini, ip)
            read.write_files('------------------------------------------', 'arxiu.txt')
            print('------------------------------------------')
            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')
                read.write_files(f'{IP} TODOS DISPONIBLES!', 'arxiu.txt')

            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP} NO DISPONIBLES!')
                read.write_files(f'{IP } NO DISPONIBLES!', 'arxiu.txt')

            else:
                print(f'{IP}: DISPONIBLE')
                read.write_files(f'{IP} DISPONIBLE', 'arxiu.txt')

            read.write_files('------------------------------------------', 'arxiu.txt')
            print('------------------------------------------')

            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()

    duracion_total_ENCRIPT(ini)
    print('Fecha actual: ',time_fin)
    read.write_files(time_fin, 'arxiu.txt')


def mode_normal(ip, ip_final, puerto, puerto_final):
    print('Rango: ', ip_final)
    print('Puerto: ', puerto)
    print('Puerto Final: ', puerto_final)

    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])
    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            break

        IP = ip
        scaner.scan(ip, puerto, 2)
        puerto = puerto + 1

        if puerto == puerto_final + 1:

            print('------------------------------------------')

            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')


            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}: NO DISPONIBLE!')


            else:
                print(f'{IP}: DISPONIBLE')

            print('------------------------------------------')

            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()


def mode_time(ip, ip_final, puerto, puerto_final):
    ini = datetime.now()

    print('Fecha actual: ', time_fin)
    print('Ip: ', ip)
    print('Rango: ', ip_final)
    print('Puerto: ', puerto)
    print('Puerto_final: ', puerto_final)

    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])

    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            print(time_fin)
            break

        IP = ip
        scaner.scan_time(ip, puerto, 5)
        puerto = puerto + 1

        if puerto == puerto_final + 1:

            duracion_ip(ini, ip)
            print('------------------------------------------')
            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')

            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP} NO DISPONIBLES!')

            else:
                print(f'{IP}: DISPONIBLE')

            print('------------------------------------------')

            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()

    duracion_total(ini)
    print('Fecha actual: ', time_fin)


"""
def mode_normal(ip, ip_final, puerto,puerto_final ):

    print('Rango: ', ip_final )
    print('Puerto: ', puerto)
    print('Puerto Final: ', puerto_final)


    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])
    read.write_files('------------------------------------------', 'arxiu.txt')
    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            break

        IP = ip
        scaner.scan(ip, puerto, 2)
        puerto = puerto + 1

        if puerto == puerto_final + 1:

            print('------------------------------------------')

            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')


            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}: NO DISPONIBLE!')


            else:
                print(f'{IP}: DISPONIBLE')

            print('------------------------------------------')


            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()

def mode_time(ip, ip_final, puerto,puerto_final ):
    ini = datetime.now()



    print('Fecha actual: ', time_fin)
    print('Ip: ',ip)
    print('Rango: ', ip_final)
    print('Puerto: ', puerto)
    print('Puerto_final: ', puerto_final)

    rango_puerto = puerto_final - puerto
    x = ip.split('.')
    ultim_num = int(x[-1])
    y = ip_final.split('.')
    rango = int(y[-1])

    print('------------------------------------------')

    while (rango + 1) != ultim_num:

        if puerto > puerto_final:
            read.write_files('Rango no valido!', 'arxiu.txt')
            print('Rango no valido!')
            read.write_files(time_fin, 'arxiu.txt')
            print(time_fin)
            break

        IP = ip
        scaner.scan_time(ip, puerto, 5)
        puerto = puerto + 1


        if puerto == puerto_final + 1:

            duracion_ip(ini, ip)
            print('------------------------------------------')
            puerto = (puerto - 1) - rango_puerto
            ultim_num = ultim_num + 1
            x.pop(-1)
            x.append(str(ultim_num))
            ip = '.'.join(x)

            if len(puerto_disponibles['DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP}TODOS DISPONIBLES!')

            elif len(puerto_disponibles['NO DISPONIBLES']) == (rango_puerto + 1):
                print(f'{IP} NO DISPONIBLES!')

            else:
                print(f'{IP}: DISPONIBLE')

            print('------------------------------------------')

            puerto_disponibles['NO DISPONIBLES'].clear()
            puerto_disponibles['DISPONIBLES'].clear()

    duracion_total(ini)
    print('Fecha actual: ',time_fin)
    read.write_files(time_fin, 'arxiu.txt')
"""




def duracion_ip_ENCRIPT(ini, ip):
    fin = datetime.now()
    result = ini - fin

    redondear = round(result.microseconds / 1000) * 1000
    duracion = result - timedelta(microseconds=result.microseconds - redondear)
    milisegundos = duracion.microseconds // 1000

    print(f'duracion del escan {ip}:  {milisegundos}ms')
    read.write_files((f'duracion del escan {ip}:  {milisegundos}ms'), 'arxiu.txt')
def duracion_total_ENCRIPT(ini):
    fin = datetime.now()
    result = ini - fin

    redondear = round(result.microseconds / 1000) * 1000
    duracion = result - timedelta(microseconds=result.microseconds - redondear)
    segundos = duracion.seconds // 1000
    milisegundos = duracion.microseconds // 1000

    print(f'duracion total de scan: {segundos}s {milisegundos}ms')
    read.write_files(f'duracion total de scan: {segundos}s {milisegundos}ms', 'arxiu.txt')

def duracion_ip(ini, ip):
    fin = datetime.now()
    result = ini - fin

    redondear = round(result.microseconds / 1000) * 1000
    duracion = result - timedelta(microseconds=result.microseconds - redondear)
    milisegundos = duracion.microseconds // 1000

    print(f'duracion del escan {ip}:  {milisegundos}ms')

def duracion_total(ini):
    fin = datetime.now()
    result = ini - fin

    redondear = round(result.microseconds / 1000) * 1000
    duracion = result - timedelta(microseconds=result.microseconds - redondear)
    segundos = duracion.seconds // 1000
    milisegundos = duracion.microseconds // 1000

    print(f'duracion total de scan: {segundos}s {milisegundos}ms')

def confirmacion(result, puerto):
    if result == 'ABIERTO':
        puerto_disponibles['DISPONIBLES'].append(puerto)

    elif result == 'CERRADO':
        puerto_disponibles['NO DISPONIBLES'].append(puerto)