import sys, socket
import read
from datetime import datetime, timedelta
import MOD



def scan_ENCRIPT(host, port, timeout):
    try:
        # aconseguir la IP del host
        host_ip = socket.gethostbyname(host)

        # log
        print("Escaneando el host: " + host + " Puerto:" + str(port))

        read.write_files(f'Escaneando el host: {host}  Puerto:  {str(port)}', 'arxiu.txt')

        # creació del socket (NO TOCAR)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set del timeout
        sock.settimeout(timeout)

        # connexió a IP i port (NO TOCAR)
        result = sock.connect_ex((host_ip, port))

        # resultat 0 vol dir que el port està obert

        sortida = 'Puerto: '
        if result == 0:
            sortida += ' ABIERTO'
            respuesta = 'ABIERTO'
            MOD.confirmacion(respuesta, port)
        # en cas contrari el port està tancat
        else:
            sortida += ' CERRADO'
            respuesta = 'CERRADO'
            MOD.confirmacion(respuesta, port)
        # tancament del socket
        print(sortida)
        read.write_files(f'{sortida}', 'arxiu.txt')
        sock.close()

    # pulsacio de CTRL+C
    except KeyboardInterrupt:
        print ("You pressed Ctrl+C")
        sys.exit()

    # detecció d'errors en la tradcció hostname --> IP
    except socket.gaierror:
        print ("Hostname could not be resolved. Exiting")
        sys.exit()

    # detecció d'errors de connexió
    except socket.error:
        print ("Couldn't connect to server")
        sys.exit()

    return result




def scan_time_ENCRIPT(host, port, timeout):
    try:
        # aconseguir la IP del host
        host_ip = socket.gethostbyname(host)

        # log
        print("Escaneando el host: " + host +" Puerto:" + str(port))
        read.write_files(f'Escaneando el host: {host}  Puerto:  {str(port)}', 'arxiu.txt')


        # creació del socket (NO TOCAR)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set del timeout
        sock.settimeout(timeout)

        # connexió a IP i port (NO TOCAR)
        result = sock.connect_ex((host_ip, port))





        # resultat 0 vol dir que el port està obert

        sortida = 'Puerto '
        if result == 0:
            sortida += ' ABIERTO'
            respuesta = 'ABIERTO'
            MOD.confirmacion(respuesta, port)

        # en cas contrari el port està tancat
        else:
            sortida += ' CERRADO'
            respuesta = 'CERRADO'
            MOD.confirmacion(respuesta, port)


    # tancament del socket
        print(sortida)
        read.write_files(f'{sortida}', 'arxiu.txt')
        sock.close()

    # pulsacio de CTRL+C
    except KeyboardInterrupt:
        print ("You pressed Ctrl+C")
        sys.exit()

    # detecció d'errors en la tradcció hostname --> IP
    except socket.gaierror:
        print ("Hostname could not be resolved. Exiting")
        sys.exit()

    # detecció d'errors de connexió
    except socket.error:
        print ("Couldn't connect to server")
        sys.exit()



    return result


def scan(host, port, timeout):
    try:
        # aconseguir la IP del host
        host_ip = socket.gethostbyname(host)

        # log
        print("Escaneando el host: " + host + " Puerto:" + str(port))


        # creació del socket (NO TOCAR)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set del timeout
        sock.settimeout(timeout)

        # connexió a IP i port (NO TOCAR)
        result = sock.connect_ex((host_ip, port))

        # resultat 0 vol dir que el port està obert

        sortida = 'Puerto: '
        if result == 0:
            sortida += ' ABIERTO'
            respuesta = 'ABIERTO'
            MOD.confirmacion(respuesta, port)
        # en cas contrari el port està tancat
        else:
            sortida += ' CERRADO'
            respuesta = 'CERRADO'
            MOD.confirmacion(respuesta, port)
        # tancament del socket
        print(sortida)
        sock.close()

    # pulsacio de CTRL+C
    except KeyboardInterrupt:
        print("You pressed Ctrl+C")
        sys.exit()

    # detecció d'errors en la tradcció hostname --> IP
    except socket.gaierror:
        print("Hostname could not be resolved. Exiting")
        sys.exit()

    # detecció d'errors de connexió
    except socket.error:
        print("Couldn't connect to server")
        sys.exit()

    return result




def scan_time(host, port, timeout):
    try:
        # aconseguir la IP del host
        host_ip = socket.gethostbyname(host)

        # log
        print("Escaneando el host: " + host +" Puerto:" + str(port))


        # creació del socket (NO TOCAR)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set del timeout
        sock.settimeout(timeout)

        # connexió a IP i port (NO TOCAR)
        result = sock.connect_ex((host_ip, port))





        # resultat 0 vol dir que el port està obert

        sortida = 'Puerto '
        if result == 0:
            sortida += ' ABIERTO'
            respuesta = 'ABIERTO'
            MOD.confirmacion(respuesta, port)

        # en cas contrari el port està tancat
        else:
            sortida += ' CERRADO'
            respuesta = 'CERRADO'
            MOD.confirmacion(respuesta, port)


    # tancament del socket
        print(sortida)
        sock.close()

    # pulsacio de CTRL+C
    except KeyboardInterrupt:
        print("You pressed Ctrl+C")
        sys.exit()

    # detecció d'errors en la tradcció hostname --> IP
    except socket.gaierror:
        print("Hostname could not be resolved. Exiting")
        sys.exit()

    # detecció d'errors de connexió
    except socket.error:
        print("Couldn't connect to server")
        sys.exit()



    return result
